Pinterest Pin It Button For Images
=============
[Official release here](http://wordpress.org/extend/plugins/pinterest-pin-it-button-for-images/)  



